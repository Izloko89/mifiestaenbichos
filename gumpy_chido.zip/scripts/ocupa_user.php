<?php //script para escribir el id de usuario o no

$ocupaUser=array(
	"clientes"=>false,
	"proveedores"=>false,
	"articulos"=>false,
	"paquetes"=>false,
	"cotizaciones"=>false,
	"articulos"=>false,
	"usuarios"=>false,
);

?>