<?php session_start();
include("func_form.php");

nuevaClaveCotizar();
?>