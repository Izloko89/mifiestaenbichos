<script src="js/formularios.js"></script>
<form id="f_areas" class="formularios">
<h3 class="titulo_form">ÁREAS</h3>
    <div class="campo_form">
        <label class="label_width">Nombre de área</label>
        <input type="text" name="nombre" class="text_mediano">
    </div>
    <div align="right">
        <input type="button" class="guardar_individual" value="GUARDAR" data-m="individual">
    </div>
</form>
<div align="right">
	<input type="button" class="volver" value="VOLVER">
</div>